<!DOCTYPE html>
<html>
<head>
    <title>Página Inicial</title>
    <style>
        
        .btn-green {
            display: inline-block;
            margin: 10px; 
            padding: 20px 40px; 
            color: white;
            background-color: #4CAF50;
            text-decoration: none;
            border-radius: 5px;
            cursor: pointer;
            border: none;
        }
        .btn-green:hover {
            background-color: #45a049;
        }
        
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        body {
            background-image: url('snackedit.png');
            background-size: cover; 
            background-position: center center; 
            background-repeat: no-repeat; 
            height: 100vh; 
            margin: 0; 
        }

        <link rel="preload" href="snackedit.png" as="image">

    </style>
</head>
<body>
    <button class="btn-green" onclick="location.href='estoque.php'">Estoque</button>
    <button class="btn-green" onclick="location.href='fila.php'">Fila</button>
</body>
</html>
